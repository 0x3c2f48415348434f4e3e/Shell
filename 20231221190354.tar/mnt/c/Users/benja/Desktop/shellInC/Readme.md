# Shell in C
Creating a simple shell written in C.
Will try to improve on it as i work on it

# Login shell
[Link][https://linuxhandbook.com/login-shell/#:~:text=Your%20entries%20are%20verified%20against%20the%20information%20stored,program%20that%20should%20be%20started%20after%20login%20succeeds.]

# What happnes when you run a command in Linux
[Link][https://www.makeuseof.com/what-happens-when-you-run-command-linux/#:~:text=When%20you%20enter%20a%20command%2C%20the%20first%20thing,to%20the%20first%20token%20in%20the%20command%20line.]

# Auto-compilation
Socket has the family called UNIX.
Can use this knowledge to create some sort of server that listens to changes within the our C-file based on something
like the time/date and then compiles if it notices any changes.

# Basic functionality of a shell
Using the shell gives us full control over our system. Now the shell is like an intepreter (Program) and  it riuns inside something called a terminal. The terminal is just an interface/application that runs the shell

Some functionality that a shell should obviously have includes:
1. Logging into the shell [Leave this for later]
2. Logging out of a shell (So if a user enters the exit command, they will exit the shell) [Done]

3. Displaying the file contents on the terminal
