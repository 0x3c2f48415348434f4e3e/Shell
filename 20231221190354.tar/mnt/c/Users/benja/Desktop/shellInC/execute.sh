#!/usr/bin/bash

gcc -Wall -pedantic main.c -o main